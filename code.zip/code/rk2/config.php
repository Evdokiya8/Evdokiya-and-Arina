<?php

    $dbhost = 'localhost';
    $dbuser = 'demo';
    $dbpassword = 'demo';
    $database = 'demo';
